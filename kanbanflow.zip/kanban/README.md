# 🗂️ KanbanFlow — Real-Time Collaborative Kanban Board
### MERN Stack · Socket.IO · Drag & Drop · JWT Auth

---

## 📁 COMPLETE FOLDER STRUCTURE

```
kanban/                             ← ROOT (your project folder)
│
├── .env                            ← Backend env vars (DO NOT commit)
├── .env.example                    ← Safe template to commit
├── .gitignore
├── package.json                    ← Root (backend) package.json
├── vercel.json                     ← Vercel deployment config
├── render.yaml                     ← Render.com deployment config
├── README.md
│
├── server/                         ← ✅ BACKEND
│   ├── index.js                    ← Entry point (Express + Socket.IO server)
│   ├── config/
│   │   └── db.js                   ← MongoDB Atlas connection
│   ├── middleware/
│   │   ├── auth.js                 ← JWT protect middleware
│   │   └── error.js                ← Global error handler
│   ├── models/
│   │   ├── User.js                 ← User schema
│   │   ├── Board.js                ← Board + members schema
│   │   ├── List.js                 ← List/column schema
│   │   └── Task.js                 ← Task/card schema
│   ├── controllers/
│   │   ├── authController.js       ← register, login, getMe, searchUsers
│   │   ├── boardController.js      ← CRUD boards, invite/remove members
│   │   ├── listController.js       ← CRUD lists
│   │   └── taskController.js       ← CRUD tasks, move tasks
│   ├── routes/
│   │   ├── auth.js                 ← /api/auth/*
│   │   ├── boards.js               ← /api/boards/*
│   │   ├── lists.js                ← /api/lists/*
│   │   └── tasks.js                ← /api/tasks/*
│   └── socket/
│       └── index.js                ← Socket.IO event handlers
│
└── client/                         ← ✅ FRONTEND (React)
    ├── .env                        ← Frontend env vars (DO NOT commit)
    ├── .env.example
    ├── package.json
    ├── public/
    │   └── index.html
    └── src/
        ├── App.js                  ← Router + providers
        ├── App.css
        ├── index.js                ← ReactDOM.render
        ├── index.css               ← Global design system (CSS vars, animations)
        │
        ├── context/
        │   ├── AuthContext.js      ← Auth state, login/register/logout
        │   └── BoardContext.js     ← Board/list/task state + socket listeners
        │
        ├── utils/
        │   ├── api.js              ← Axios instance with JWT interceptors
        │   └── socket.js           ← Socket.IO connect/disconnect helpers
        │
        ├── components/
        │   ├── common/
        │   │   ├── Avatar.jsx          ← Coloured initial avatars
        │   │   ├── Button.jsx          ← Reusable button (variants + loading)
        │   │   ├── Input.jsx           ← Reusable input (label, error, icon, password toggle)
        │   │   ├── Modal.jsx           ← Overlay modal (Esc to close)
        │   │   ├── Spinner.jsx         ← Loading spinner
        │   │   └── ProtectedRoute.jsx  ← Auth guard for private routes
        │   │
        │   ├── board/
        │   │   ├── ListColumn.jsx      ← Droppable column with header menu
        │   │   └── InviteModal.jsx     ← Invite/remove members modal
        │   │
        │   └── task/
        │       ├── TaskCard.jsx        ← Draggable task card (priority, labels, due date)
        │       └── TaskModal.jsx       ← Create/edit task modal
        │
        └── pages/
            ├── LoginPage.jsx       ← /login
            ├── RegisterPage.jsx    ← /register
            ├── DashboardPage.jsx   ← /dashboard  (board grid)
            ├── BoardPage.jsx       ← /board/:id  (kanban canvas)
            └── NotFoundPage.jsx    ← 404
```

---

## ⚙️ STEP 1 — Fill in your .env (Backend)

Open `/kanban/.env` and fill:

```
MONGO_URI=mongodb+srv://youruser:yourpass@cluster.mongodb.net/kanbanflow?retryWrites=true&w=majority
JWT_SECRET=any_long_random_string_here
JWT_EXPIRE=7d
PORT=5000
NODE_ENV=development
CLIENT_URL=http://localhost:3000
```

Open `/kanban/client/.env` (frontend):

```
REACT_APP_API_URL=http://localhost:5000/api
REACT_APP_SOCKET_URL=http://localhost:5000
```

---

## 🚀 STEP 2 — Run Locally

```bash
# 1. Go to root folder
cd kanban

# 2. Install backend dependencies
npm install

# 3. Install frontend dependencies
cd client && npm install && cd ..

# 4. Run both together (dev mode)
npm run dev
```

- Frontend → http://localhost:3000  
- Backend  → http://localhost:5000  
- API test → http://localhost:5000/api/health

---

## 🐙 STEP 3 — Push to GitHub

```bash
cd kanban
git init
git add .
git commit -m "Initial commit — KanbanFlow MERN app"
git remote add origin https://github.com/YOUR_USERNAME/kanbanflow.git
git push -u origin main
```

---

## ☁️ STEP 4 — Deploy Backend on Render (Free)

1. Go to https://render.com → New → Web Service
2. Connect your GitHub repo
3. Set these settings:
   - **Root Directory**: ` ` (leave blank, use repo root)
   - **Build Command**: `npm install`
   - **Start Command**: `npm start`
4. Add Environment Variables in Render dashboard:
   ```
   MONGO_URI         = <your Atlas URI>
   JWT_SECRET        = <your secret>
   JWT_EXPIRE        = 7d
   NODE_ENV          = production
   CLIENT_URL        = https://your-app.vercel.app   ← update after step 5
   ```
5. Click **Deploy** → copy the URL e.g. `https://kanbanflow-api.onrender.com`

---

## 🌐 STEP 5 — Deploy Frontend on Vercel (Free)

1. Go to https://vercel.com → New Project → Import your GitHub repo
2. Set **Root Directory** to `client`
3. Add Environment Variables:
   ```
   REACT_APP_API_URL    = https://kanbanflow-api.onrender.com/api
   REACT_APP_SOCKET_URL = https://kanbanflow-api.onrender.com
   ```
4. Click **Deploy** → copy the URL e.g. `https://kanbanflow.vercel.app`
5. Go back to **Render dashboard** → update `CLIENT_URL` to your Vercel URL → Redeploy

---

## 🔑 API Endpoints Summary

| Method | Endpoint                        | Auth | Description              |
|--------|---------------------------------|------|--------------------------|
| POST   | /api/auth/register              | ❌   | Register new user        |
| POST   | /api/auth/login                 | ❌   | Login                    |
| GET    | /api/auth/me                    | ✅   | Get current user         |
| GET    | /api/auth/search?q=email        | ✅   | Search users             |
| GET    | /api/boards                     | ✅   | Get all my boards        |
| POST   | /api/boards                     | ✅   | Create board             |
| GET    | /api/boards/:id                 | ✅   | Get board with lists+tasks|
| PATCH  | /api/boards/:id                 | ✅   | Update board             |
| DELETE | /api/boards/:id                 | ✅   | Delete board             |
| POST   | /api/boards/:id/invite          | ✅   | Invite member by email   |
| DELETE | /api/boards/:id/members/:userId | ✅   | Remove member            |
| POST   | /api/lists                      | ✅   | Create list              |
| PATCH  | /api/lists/:id                  | ✅   | Update/rename list       |
| DELETE | /api/lists/:id                  | ✅   | Delete list + tasks      |
| POST   | /api/tasks                      | ✅   | Create task              |
| PATCH  | /api/tasks/:id                  | ✅   | Update task              |
| DELETE | /api/tasks/:id                  | ✅   | Delete task              |
| PATCH  | /api/tasks/:id/move             | ✅   | Move task to another list|

---

## ⚡ Socket Events

| Event              | Direction        | Payload                        |
|--------------------|------------------|--------------------------------|
| board:join         | client → server  | boardId                        |
| board:leave        | client → server  | boardId                        |
| user:joined        | server → clients | { userId, name, avatar }       |
| user:left          | server → clients | { userId }                     |
| list:created       | server → clients | list object                    |
| list:updated       | server → clients | list object                    |
| list:deleted       | server → clients | { listId }                     |
| task:created       | server → clients | task object                    |
| task:updated       | server → clients | task object                    |
| task:moved         | server → clients | task object                    |
| task:deleted       | server → clients | { taskId }                     |
| board:updated      | server → clients | board object                   |
| board:memberAdded  | server → clients | { board, newMember }           |
| board:memberRemoved| server → clients | { board, removedUserId }       |
