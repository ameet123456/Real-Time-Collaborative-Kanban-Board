import React from 'react';
import { Navigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import Spinner from './Spinner';

export default function ProtectedRoute({ children }) {
  const { user, loading } = useAuth();

  if (loading) {
    return (
      <div style={{
        minHeight:'100vh', display:'flex', alignItems:'center', justifyContent:'center',
        background:'var(--bg-base)', gap:'1rem', flexDirection:'column',
      }}>
        <Spinner size={36} />
        <p style={{ color:'var(--text-muted)', fontSize:'0.85rem' }}>Loading…</p>
      </div>
    );
  }

  return user ? children : <Navigate to="/login" replace />;
}
